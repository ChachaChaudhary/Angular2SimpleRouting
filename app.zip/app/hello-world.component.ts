import { Component } from '@angular/core';


@Component({
    
selector: 'hello-world',
    
template: ' <div>Hello {{name}}</div><input type="text" [(ngModel)]="name">'
})

export class HelloWorldComponent {
    name: any;
}