import { Component } from '@angular/core';


@Component({
     
template: '<h2>Test Set</h2>'
})

export class TestSetComponent {
}