import { NgModule }      from '@angular/core';

import { BrowserModule } from '@angular/platform-browser';

import { FormsModule } from '@angular/forms';

import { RouterModule, Routes } from '@angular/router';
import { AppComponent }   from './app.component';
import { TestSetComponent }   from './testSet.component';

import { TestComponent }   from './test.component';
 const appRoutes: Routes = [ 
{ path: 'testset', component: TestSetComponent}, 
{ path: 'test', component: TestComponent }, ]; 
@NgModule({
  
imports:      [ BrowserModule,FormsModule,RouterModule.forRoot(appRoutes) ],
  
declarations: [ AppComponent,TestSetComponent,TestComponent ],

  bootstrap:    [ AppComponent ]
})

export class AppModule { }