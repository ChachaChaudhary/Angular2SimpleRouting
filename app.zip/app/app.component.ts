import { Component } from '@angular/core';


@Component({
    
selector: 'main-app',
    
template: '<h1>Automation Portal</h1> <nav> <a routerLink="/testset" routerLinkActive="active">Test Set</a> <a routerLink="/test" routerLinkActive="active">Test</a> </nav> <router-outlet></router-outlet>'
})

export class AppComponent {

}